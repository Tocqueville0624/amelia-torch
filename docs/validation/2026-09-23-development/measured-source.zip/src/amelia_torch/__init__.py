"""Experimental Amelia 1.8.3-compatible numerical kernels and continuous EMB."""

from .api import AmeliaInputError, amelia
from .backends import resolve_backend
from .em import em_fit

__version__ = "0.0.1"
__all__ = ["AmeliaInputError", "amelia", "em_fit", "resolve_backend"]
